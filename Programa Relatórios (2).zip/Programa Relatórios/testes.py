positivos = ["Sim", "sim", "SIM"]
negativos = ["não", "NÃO", "Não"]
resposta = input("Teste: ")
for escolha in positivos or negativos:
    if resposta == positivos:
        print("esc Sim")
    else:
            if resposta == negativos:
                print("esc não")
            else:
                if resposta != escolha:
                    print("errou paizão")