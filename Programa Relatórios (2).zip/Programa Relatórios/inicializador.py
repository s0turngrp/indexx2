import subprocess
import os

os.system('color a')
os.system('cls')
ascii_art = """
    _______                    ____              _    
   |__   __|                  |  _ \            | |   
      | | ___  ___ _ __   ___ | |_) | ___   ___ | | __
      | |/ _ \/ __| '_ \ / _ \|  _ < / _ \ / _ \| |/ /
      | |  __/ (__| | | | (_) | |_) | (_) | (_) |   < 
      |_|\___|\___|_| |_|\___/|____/ \___/ \___/|_|\_|
ASSISTÊNCIA TÉCNICA ESPECIALIZADA EM CONSERTO DE CELULARES
                  Seleção de Programa                                                  
"""
print(ascii_art)
input("Pressione Enter: ")

print("--------------------------------------------------------")
print("Selecione o programa que deseja:")

print("Relatório quinzenal    = 1")
print("Relatório Mensal       = 2")
print("Relatório de Depósitos = 3")
print("Códigos de erro        = 4")
programa = int(input(": ")) 

if programa == 1:
    subprocess.run([
    r"C:\Users\vinit\AppData\Local\Microsoft\WindowsApps\python.exe", 
    r"C:\Users\vinit\OneDrive\Área de Trabalho\Programa Relatórios\quinzenal_data\prot_quinzenal.py"
])

if programa == 2:
        subprocess.run([
    r"C:\Users\vinit\AppData\Local\Microsoft\WindowsApps\python.exe", 
    r"C:\Users\vinit\OneDrive\Área de Trabalho\Programa Relatórios\mensal_data\prot_mensal.py"
])

if programa == 3:
    subprocess.run([
    r"C:\Users\vinit\AppData\Local\Microsoft\WindowsApps\python.exe", 
    r"C:\Users\vinit\OneDrive\Área de Trabalho\Programa Relatórios\deposito_data\prot_depositos.py"       
])
    
if programa == 4:
    subprocess.run([
    r"C:\Users\vinit\AppData\Local\Microsoft\WindowsApps\python.exe", 
    r"C:\Users\vinit\OneDrive\Área de Trabalho\Programa Relatórios\errors_changelog\códigos de erro.py"       
])