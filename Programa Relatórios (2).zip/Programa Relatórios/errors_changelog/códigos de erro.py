import os
import subprocess

os.system('color a')
os.system('cls')
ascii_art = """
    _______                    ____              _    
   |__   __|                  |  _ \            | |   
      | | ___  ___ _ __   ___ | |_) | ___   ___ | | __
      | |/ _ \/ __| '_ \ / _ \|  _ < / _ \ / _ \| |/ /
      | |  __/ (__| | | | (_) | |_) | (_) | (_) |   < 
      |_|\___|\___|_| |_|\___/|____/ \___/ \___/|_|\_|
ASSISTÊNCIA TÉCNICA ESPECIALIZADA EM CONSERTO DE CELULARES
                     Códigos de Erro                                                  
"""
print(ascii_art)
input("Pressione Enter: ")
print("--------------------------------------------------------")

print("Escolha o que deseja: ")
print("Buscador de erros: Enter  |  Procurar na Biblioteca: 1")
seleção = input()

#Definição de erros:

#fim

busca = []
while True:
    os.system('cls')
    print(ascii_art)
    if seleção != 1:
     print("Selecionado: Buscador")
     buscado = int(input("Digite o código do erro: "))
     if buscado == 100:
        print("")
        print("ERRO 100: Este erro ocorre quando o valor que você adicionou\nnão é considerado numérico, logo não pode ser calculado ou\n adicionado corretamente no projeto. Insira apenas números, pontos e vígulas\ne o código rolará normalmente.")
        print("")
    if input("Buscar outro erro: 1\nContinuar: Enter\n") != "1":
            break