import json
from docx import Document

def carregar_dados(arquivo="dados_coletados_m.json"):
    with open(arquivo, "r", encoding="utf-8") as f:
        return json.load(f)

def gerar_relatorio_mensal(dados_json):
    faturamento_total = dados_json["faturamento_total"]
    despesas = dados_json["despesas"]
    faturamento_liquido = faturamento_total - despesas
    dados_lojas = dados_json["dados_lojas"]
    mes = dados_lojas[0]['mes']
    ano = dados_lojas[0]['ano']
    nome_arquivo = f"Relatório de Faturamento Mensal ({mes}-{ano}).docx"
    
    doc = Document()
    doc.add_heading(f"RELATÓRIO DE FATURAMENTO MENSAL", level=1)
    doc.add_paragraph(f"({mes.upper()} {ano})\n\n")
    
    for loja in dados_lojas:
        doc.add_heading(f"LOJA {loja['nome'].upper()}", level=2)
        doc.add_paragraph(
            f"O total de vendas do mês foi de: R$ {loja['total_vendas']:.2f}.\n"
            f"Dia {loja['maior_dia']} ({loja['maior_dia_semana']}) foi o dia de maior entrada no caixa, com valor de R$ {loja['maior_dia_valor']:.2f}.\n"
            f"O dia que teve menor fluxo de vendas foi {loja['menor_dia']} ({loja['menor_dia_semana']}), com valor de R$ {loja['menor_dia_valor']:.2f}.\n"
        )
        
        doc.add_paragraph("Vendas por vendedor:")
        for vendedor in loja['vendedores']:
            doc.add_paragraph(
                f" - {vendedor['nome']} efetuou {vendedor['qtd_vendas']} vendas, totalizando R$ {vendedor['total_vendas']:.2f}."
            )
        
        if loja['nome'] != "TB Cases":
            doc.add_paragraph(
                f"O total de vendas foi dividido em R$ {loja['vendas_kyte']:.2f} no Kyte e R$ {loja['vendas_os']:.2f} em Ordens de Serviço.\n"
                f"Houve um total de {loja['total_aparelhos_reparo']} aparelhos para reparo no mês.\n"
                f"Dia {loja['maior_entrada_aparelho']} teve a maior entrada de aparelhos ({loja['maior_entrada_qtd']} aparelhos).\n"
                f"Dia {loja['menor_entrada_aparelho']} teve a menor entrada de aparelhos ({loja['menor_entrada_qtd']} aparelhos)."
            )
        
        doc.add_paragraph(
            f"Participação da loja no faturamento total: {loja['percentual_faturamento']:.2f}%\n"
        )
    
    doc.add_heading("FATURAMENTO TOTAL", level=2)
    doc.add_paragraph(f"O faturamento bruto total do mês foi de: R$ {faturamento_total:.2f}.\n")
    doc.add_paragraph(f"Total de despesas no mês: R$ {despesas:.2f}.\n")
    doc.add_paragraph(f"Faturamento líquido total do mês: R$ {faturamento_liquido:.2f}.\n")
    
    doc.save(nome_arquivo)
    print(f"Relatório salvo como {nome_arquivo}")

if __name__ == "__main__":
    dados = carregar_dados()  # Carrega os dados do JSON
    gerar_relatorio_mensal(dados)  # Gera o relatório
