from docx import Document

def gerar_relatorio(dados_lojas, total_geral_deposito, arquivo="deposito_diario.docx"):
    doc = Document()
    doc.add_heading(f"DEPOSITAR DIA {dados_lojas[0]['intervalo']}", level=1)
    doc.add_paragraph("\n")
    
    for loja in dados_lojas:
        doc.add_paragraph(f"CAIXA {loja['nome'].upper()} DO DIA {loja['data_colhida']}")
        doc.add_paragraph("CAIXA FINAL EM DINHEIRO:")
        doc.add_paragraph(f"R$ {loja['real_deposito']:.2f}")
        doc.add_paragraph("_____________________________________________________________________")
    
    doc.add_paragraph("\nTOTAL GERAL:")
    for loja in dados_lojas:
        doc.add_paragraph(f"R$ {loja['real_deposito']:.2f}")
    doc.add_paragraph(f"= R$ {total_geral_deposito:.2f}")
    
    doc.add_paragraph("\nSERÁ DEPOSITADO")
    doc.add_paragraph(f"R$ {total_geral_deposito:.2f}")
    
    doc.save(arquivo)
    print(f"Relatório gerado: {arquivo}")

if __name__ == "__main__":
    import json
    with open("dados_coletados_d.json", "r", encoding="utf-8") as f:
        dados = json.load(f)
    
    total_geral_deposito = sum(loja["real_deposito"] for loja in dados)
    gerar_relatorio(dados, total_geral_deposito)
