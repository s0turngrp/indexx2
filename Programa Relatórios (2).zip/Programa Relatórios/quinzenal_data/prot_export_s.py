import json
from docx import Document

def carregar_dados(arquivo="dados_coletados_s.json"):
    with open(arquivo, "r", encoding="utf-8") as f:
        return json.load(f)

def gerar_relatorio(dados_lojas):
    intervalo = dados_lojas[0]['intervalo'].replace("/", "-")  # Substitui barras por hífens para evitar problemas no nome do arquivo
    nome_arquivo = f"Relatório ({intervalo}).docx"  # Define o nome do arquivo com a data do intervalo

    doc = Document()
    doc.add_heading("RELATÓRIO", level=1)
    doc.add_paragraph(f"({dados_lojas[0]['intervalo']})\n\n")

    for loja in dados_lojas:
        doc.add_heading(f"LOJA {loja['nome'].upper()}", level=2)
        doc.add_paragraph(
            f"Da data de {loja['intervalo']} houve um total de vendas de R$ {loja['total_vendas']:.2f}, "
            f"sendo que o dia {loja['maior_dia']} ({loja['maior_dia_semana']}) foi o dia que teve o maior valor de vendas "
            f"com um total de R$ {loja['maior_venda']:.2f}. E o dia {loja['menor_dia']} ({loja['menor_dia_semana']}) "
            f"teve o menor valor de vendas, totalizando R$ {loja['menor_venda']:.2f}.\n"
        )

        if 'vendas_kyte' in loja:
            doc.add_paragraph(f"Do total de vendas: R$ {loja['vendas_kyte']:.2f} no Kyte.")
            doc.add_paragraph(f"Total de vendas OS: R$ {loja['vendas_os']:.2f}\n")

        if 'total_entradas' in loja:
            doc.add_paragraph(f"Teve um total de {loja['total_entradas']} entradas de Ordens de Serviço ")
            doc.add_paragraph(f"e {loja['total_saidas']} saídas de Ordens de Serviço nesse período.\n")

            doc.add_paragraph("Dias com maior número de entradas de aparelhos:")
            if 'maior_entrada_dias' in loja:
                for dia, semana, qtd in loja['maior_entrada_dias']:
                    doc.add_paragraph(f" - Dia {dia} ({semana}): {qtd} aparelhos")

            doc.add_paragraph("Dias com menor número de entradas de aparelhos:")
            if 'menor_entrada_dias' in loja:
                for dia, qtd in loja['menor_entrada_dias']:
                    doc.add_paragraph(f" - Dia {dia}: {qtd} aparelhos")

    doc.save(nome_arquivo)
    print(f"Relatório salvo como {nome_arquivo}")

if __name__ == "__main__":
    dados = carregar_dados()  # Carrega os dados do JSON
    gerar_relatorio(dados)  # Gera o relatório
