import json
import os
import subprocess
from datetime import datetime



os.system('color a')
os.system('cls')
ascii_art = """
    _______                    ____              _    
   |__   __|                  |  _ \            | |   
      | | ___  ___ _ __   ___ | |_) | ___   ___ | | __
      | |/ _ \/ __| '_ \ / _ \|  _ < / _ \ / _ \| |/ /
      | |  __/ (__| | | | (_) | |_) | (_) | (_) |   < 
      |_|\___|\___|_| |_|\___/|____/ \___/ \___/|_|\_|
ASSISTÊNCIA TÉCNICA ESPECIALIZADA EM CONSERTO DE CELULARES
                  Relatório Quinzenal                                                  
"""
print(ascii_art)
input("Pressione Enter: ")

print("--------------------------------------------------------")

def converter_para_float(valor_str):
    """Converte valores no formato brasileiro para float (ex: 26.232,42 -> 26232.42)"""
    try:
        valor_str = valor_str.replace('.', '').replace(',', '.')  # Remove ponto do milhar e troca vírgula por ponto
        return float(valor_str)
    except ValueError:
        print("ERRO_1. Valor inválido. Tente novamente:")
        return converter_para_float(input("Digite novamente o valor no formato correto (ex: 26.232,42): "))

def obter_dia_semana(data_str, ano_padrao=None):
    """Recebe data no formato 'DD/MM' ou 'DD/MM/AAAA' e retorna o dia da semana."""
    partes = list(map(int, data_str.split("/")))
    
    if len(partes) == 2 and ano_padrao:
        dia, mes = partes
        ano = ano_padrao
    else:
        dia, mes, ano = partes
    
    data_completa = datetime(ano, mes, dia)
    dias_semana = ["Segunda-feira", "Terça-feira", "Quarta-feira", "Quinta-feira", "Sexta-feira", "Sábado", "Domingo"]
    return dias_semana[data_completa.weekday()]


def coletar_dados():
    lojas = ["TB Cases", "SJP", "Sucupira do Riachão", "Passagem Franca", "Colinas"]
    
    intervalo_inicio = input("Digite a data de início do relatório (DD/MM/AAAA): ")
    intervalo_fim = input("Digite a data de fim do relatório (DD/MM/AAAA): ")
    
    _, _, ano = intervalo_inicio.split("/")
    ano = int(ano)

    dados_lojas = []
    
    for loja in lojas:
        print(f"\nColetando dados para a loja {loja}...")
        total_vendas = float(input("Total de vendas no período (R$): "))
        maior_dia = input("Dia com maiores vendas (DD/MM): ")
        maior_dia_semana = obter_dia_semana(maior_dia, ano)
        maior_venda = float(input("Valor do maior dia de vendas (R$): "))
        menor_dia = input("Dia com menores vendas (DD/MM): ")
        menor_dia_semana = obter_dia_semana(menor_dia, ano)
        menor_venda = float(input("Valor do menor dia de vendas (R$): "))
       
        dados_loja = {
            "nome": loja,
            "intervalo": f"{intervalo_inicio} a {intervalo_fim}",
            "total_vendas": total_vendas,
            "maior_dia": maior_dia,
            "maior_dia_semana": maior_dia_semana,  
            "maior_venda": maior_venda,
            "menor_dia": menor_dia,
            "menor_dia_semana": menor_dia_semana,  
            "menor_venda": menor_venda
        }
        
        if loja != "TB Cases":
            vendas_kyte = float(input("Total de vendas Registradas no Kyte (R$): "))
            vendas_os = total_vendas - vendas_kyte
            print(f"Total de vendas OS (R$): {vendas_os:.2f}")

            total_entradas = int(input("Total de entradas de aparelhos: "))
            total_saidas = int(input("Total de saídas de aparelhos: "))
            
            maior_entrada_dias = []
            contadorM = 0
            while True:
                dia = input("Data do maior número de entradas (DD/MM): ")
                semana = obter_dia_semana(dia, ano)
                if contadorM == 0:
                    qtd = int(input("Quantidade de aparelhos na maior entrada: "))
                    contadorM = 1
                maior_entrada_dias.append((dia, semana, qtd))
                if input("Adicionar data: 1\nContinuar: Enter\n") != "1":
                    break
            
            menor_entrada_dias = []
            contadorm = 0
            while True:
                dia = input("Data do menor número de entradas (DD/MM): ")
                if contadorm == 1:
                    qtd = int(input("Quantidade de aparelhos na menor entrada: "))
                    contadorm = 1
                menor_entrada_dias.append((dia, qtd))
                if input("Adicionar data: 1\nContinuar: Enter\n") != "1":
                    break
            
            dados_loja.update({
                "vendas_kyte": vendas_kyte,
                "vendas_os": vendas_os,
                "total_entradas": total_entradas,
                "total_saidas": total_saidas,
                "maior_entrada_dias": maior_entrada_dias,
                "menor_entrada_dias": menor_entrada_dias
            })
        
        dados_lojas.append(dados_loja)
    
    return dados_lojas


def salvar_dados(dados, arquivo="dados_coletados_s.json"):
    with open(arquivo, "w", encoding="utf-8") as f:
        json.dump(dados, f, indent=4, ensure_ascii=False)
    print(f"Dados salvos em {arquivo}")


if __name__ == "__main__":
    dados = coletar_dados()
    print("\nDados coletados com sucesso!")
    salvar_dados(dados)
    subprocess.run([r"C:\\Users\\vinit\\AppData\\Local\\Microsoft\\WindowsApps\\python.exe", "prot_export_s.py"])