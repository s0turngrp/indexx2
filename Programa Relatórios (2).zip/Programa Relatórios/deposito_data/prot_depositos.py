import json
import os
import time
import subprocess

os.system('color a')
os.system('cls')

ascii_art = """
    _______                    ____              _    
   |__   __|                  |  _ \            | |   
      | | ___  ___ _ __   ___ | |_) | ___   ___ | | __
      | |/ _ \/ __| '_ \ / _ \|  _ < / _ \ / _ \| |/ /  
      | |  __/ (__| | | | (_) | |_) | (_) | (_) |   <  
      |_|\___|\___|_| |_|\___/|____/ \___/ \___/|_|\_|  
ASSISTÊNCIA TÉCNICA ESPECIALIZADA EM CONSERTO DE CELULARES
               Relatório de Depósito Diário                                                  
"""
print(ascii_art)
input("Pressione Enter: ")

print("--------------------------------------------------------")

positivos = ["Sim", "sim", "SIM"]
negativos = ["Não", "não", "NÃO"]

def converter_para_float(valor_str):
    """Converte valores no formato brasileiro para float (ex: 26.232,42 -> 26232.42)"""
    try:
        valor_str = valor_str.replace('.', '').replace(',', '.')  
        return float(valor_str)
    except ValueError:
        print("ERRO_100. Valor inválido. Tente novamente:")
        return converter_para_float(input("Digite novamente o valor no formato correto (ex: 26.232,42): "))


def coletar_dados():
    lojas = ["TB Cases", "SJP", "Sucupira do Riachão", "Passagem Franca", "Colinas"]
    
    intervalo_inicio = input("Digite a data do relatório (DD/MM/AAAA): ")

    dados_lojas = []
    total_geral_deposito = 0  # Variável para armazenar a soma total de depósitos

    for loja in lojas:
        while True:
            print(f"\nDeseja coletar os dados de depósito de {loja}? ")
            time.sleep(0.75)
            print("Sim ou Não?")
            escolha = input()

            if escolha in positivos:  
                if loja not in ["TB Cases", "SJP"]:
                    data_colhida = input("Digite o dia correspondente ao valor enviado no envelope (DD/MM): ")
                else:
                    data_colhida = intervalo_inicio  
                    print(f"Dados de depósito de {loja} referente a {data_colhida}: ")

                total_caixa = converter_para_float(input("Valor encontrado em caixa (R$): "))

                retiradas = []
                while True:
                    decisao = input("Houveram retiradas? (Sim ou Não): ")
                    if decisao in positivos:
                        retirada_valor = converter_para_float(input("Digite o valor da retirada (R$): "))
                        retiradas.append(retirada_valor)
                        
                        if input("Adicionar outra retirada? (1 para adicionar, Enter para continuar): ") != "1":
                            break
                    elif decisao in negativos:
                        break
                    else:
                        print("ERRO 102: Digite uma entrada válida (Sim ou Não)")

                total_retiradas = sum(retiradas)  # Soma todas as retiradas da loja
                real_deposito = total_caixa - total_retiradas  # Valor final a ser depositado para essa loja
                
                total_geral_deposito += real_deposito  # Acumulando para o total geral

                print(f"Valor a se depositar para {loja}: R$ {real_deposito:.2f}\n")

                dados_loja = {
                    "nome": loja,
                    "data_colhida": data_colhida,
                    "intervalo": intervalo_inicio,
                    "total_vendas": total_caixa,
                    "total_retiradas": total_retiradas,
                    "real_deposito": real_deposito
                }

                dados_lojas.append(dados_loja)
                break  # Passa para a próxima loja

            elif escolha in negativos:
                print(f"Dados de {loja} não foram coletados.\n")
                break  

            else:
                print("ERRO 102: Digite uma entrada válida (Sim ou Não)")

    print("--------------------------------------------------------")
    print(f"\nTOTAL GERAL A SER DEPOSITADO: R$ {total_geral_deposito:.2f}")
    print("--------------------------------------------------------")
    
    return dados_lojas


def salvar_dados(dados, arquivo="dados_coletados_d.json"):
    with open(arquivo, "w", encoding="utf-8") as f:
        json.dump(dados, f, indent=4, ensure_ascii=False)
    print(f"Dados salvos em {arquivo}")


if __name__ == "__main__":
    dados = coletar_dados()
    print("\nDados coletados com sucesso!")
    salvar_dados(dados)

if __name__ == "__main__":
    dados = coletar_dados()
    print("\nDados coletados com sucesso!")
    salvar_dados(dados)
    subprocess.run([r"C:\\Users\\vinit\\AppData\\Local\\Microsoft\\WindowsApps\\python.exe", "prot_export_d.py"])
